/*
Created by: Md. Ashraful Islam
*/

#include <stdio.h>
#include <SDL.h>

int main(int argc, char* argv[]) {
    // You have access to all SDL library functions and user defined types
    return 0;
}
